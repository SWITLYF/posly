<?php

namespace App\Http\Resources;

/**
 * Class ExpenseCategoryCollection
 */
class ExpenseCategoryCollection extends BaseCollection
{
    public $collects = ExpenseCategoryResource::class;
}
