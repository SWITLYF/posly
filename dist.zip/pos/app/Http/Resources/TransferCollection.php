<?php

namespace App\Http\Resources;

/**
 * Class TransferCollection
 */
class TransferCollection extends BaseCollection
{
    public $collects = TransferResource::class;
}
