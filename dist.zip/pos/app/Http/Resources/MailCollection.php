<?php

namespace App\Http\Resources;

/**
 * Class MailCollection
 */
class MailCollection extends BaseCollection
{
    public $collects = MailResource::class;
}
