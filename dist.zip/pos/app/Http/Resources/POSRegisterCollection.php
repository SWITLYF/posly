<?php

namespace App\Http\Resources;

/**
 * Class POSRegisterCollection
 */
class POSRegisterCollection extends BaseCollection
{
    public $collects = POSRegisterResource::class;
}
