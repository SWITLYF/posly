<?php

namespace App\Http\Resources;

/**
 * Class SaleResource
 */
class SalesPaymentResource extends BaseJsonResource
{
}
