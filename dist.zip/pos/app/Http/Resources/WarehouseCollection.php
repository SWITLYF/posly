<?php

namespace App\Http\Resources;

/**
 * Class WarehouseCollection
 */
class WarehouseCollection extends BaseCollection
{
    public $collects = WarehouseResource::class;
}
