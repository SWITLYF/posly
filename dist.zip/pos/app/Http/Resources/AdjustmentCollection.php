<?php

namespace App\Http\Resources;

/**
 * Class AdjustmentCollection
 */
class AdjustmentCollection extends BaseCollection
{
    public $collects = AdjustmentResource::class;
}
