<?php

namespace App\Http\Resources;

/**
 * Class ProductResource
 */
class ProductResource extends BaseJsonResource
{
}
