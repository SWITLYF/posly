<?php

namespace App\Http\Resources;

/**
 * Class ManageStockCollection
 */
class ManageStockCollection extends BaseCollection
{
    public $collects = ManageStockResource::class;
}
