<?php

namespace App\Http\Resources;

/**
 * Class MailResource
 */
class MailResource extends BaseJsonResource
{
}
