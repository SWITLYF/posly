<?php

namespace App\Http\Resources;

/**
 * Class CustomerResource
 */
class CustomerResource extends BaseJsonResource
{
}
