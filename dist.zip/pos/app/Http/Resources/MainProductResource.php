<?php

namespace App\Http\Resources;

/**
 * Class AdjustmentResource
 */
class MainProductResource extends BaseJsonResource
{
    
}
